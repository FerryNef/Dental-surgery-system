package com.ads.dentalapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
