package com.ads.dentalapp.model;

public enum AppointmentStatus {
    SCHEDULED,
    REQUESTED_CANCEL,
    REQUESTED_CHANGE,
    CANCELLED,
    APPROVED,
}
