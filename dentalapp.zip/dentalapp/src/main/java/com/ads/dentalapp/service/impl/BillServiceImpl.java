package com.ads.dentalapp.service.impl;
import com.ads.dentalapp.model.Bill;
import com.ads.dentalapp.model.Patient;
import com.ads.dentalapp.model.User;
import com.ads.dentalapp.repository.BillRepository;
import com.ads.dentalapp.repository.PatientRepository;
import com.ads.dentalapp.repository.UserRepository;
import com.ads.dentalapp.service.BillService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BillServiceImpl implements BillService {

    private final BillRepository billRepository;
    private final UserRepository userRepository;
    private final PatientRepository patientRepository;


    @Override
    public Bill updateBill(Long billId, BigDecimal newAmount) {
        Bill bill =billRepository.findById(billId)
                .orElseThrow(()-> new RuntimeException("Bill not found"));

        bill.setAmount(newAmount);

        if (newAmount.compareTo(BigDecimal.ZERO) > 0) {
            bill.setStatus("paid");
        }
        return billRepository.save(bill);
    }

    @Override
    public List<Bill> getBillsForLoggedPatient() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Patient patient = patientRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        return billRepository.findByPatientId(patient.getId());
    }


    @Override
    public boolean hasUnpaidBills(Long patientId) {
        return billRepository.findByPatientId(patientId)
                .stream()
                .anyMatch(bill -> bill.getStatus().equalsIgnoreCase("unpaid"));
    }
}
