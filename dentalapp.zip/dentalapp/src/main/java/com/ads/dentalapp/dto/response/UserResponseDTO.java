package com.ads.dentalapp.dto.response;

public record UserResponseDTO(

        String email,
        RoleResponseDTO role
) {
}
