package com.ads.dentalapp.dto.request;

public record RoleRequestDTO(

        String name
) {
}
