package com.ads.dentalapp.controller;

import com.ads.dentalapp.dto.request.AppointmentRequestDTO;
import com.ads.dentalapp.dto.request.DentistRequestDTO;
import com.ads.dentalapp.dto.request.PatientRequestDTO;
import com.ads.dentalapp.dto.response.PatientResponseDTO;
import com.ads.dentalapp.mapper.DentistMapper;
import com.ads.dentalapp.mapper.PatientMapper;
import com.ads.dentalapp.model.Patient;
import com.ads.dentalapp.repository.DentistRepository;
import com.ads.dentalapp.service.AppointmentService;
import com.ads.dentalapp.service.BillService;
import com.ads.dentalapp.service.DentistService;
import com.ads.dentalapp.service.PatientService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/manager")
@PreAuthorize("hasRole('OFFICE_MANAGER')")
public class OfficeManagerController {
    private DentistService dentistService;
    private DentistMapper dentistMapper;
    private AppointmentService appointmentService;
    private PatientService patientService;
    private PatientMapper patientMapper;

    private BillService billService;

    @GetMapping
    public String getManagerDashboard() {
        return "Welcome, Office Manager!";
    }

    @PostMapping("/Dentist")
    public ResponseEntity<String> registerDentist (@RequestBody DentistRequestDTO dentistRequestDTO) {
        dentistService.saveDentist(dentistRequestDTO);
        return ResponseEntity.ok("Dentist registered successfully");

    }

    @GetMapping("/patient/{id}")
    public ResponseEntity<PatientResponseDTO> getPatientById(@PathVariable Long id) {
        Patient patient= patientService.getPatientById(id);
        return ResponseEntity.ok(patientMapper.toDto(patient));
    }
    @GetMapping("/patients")
    public List<PatientResponseDTO> getAllPatients() {
        List<Patient> patients = patientService.getAllPatientsSortedByLastName();
        return patientMapper.toDtoList(patients);
    }
    @PostMapping("/patient")
    @PreAuthorize("hasAuthority('member:write')")
    public ResponseEntity<String> registerPatient(@RequestBody PatientRequestDTO dto) {
        patientService.savePatient(dto);
        return ResponseEntity.ok("Patient registered successfully");
    }

    @GetMapping("/search/{searchString}")
    public ResponseEntity<List<PatientResponseDTO>> searchPatients(@PathVariable String searchString) {
        List<Patient> patients = patientService.searchPatients(searchString);
        return ResponseEntity.ok(patientMapper.toDtoList(patients));
    }

    @DeleteMapping("Patient/{id}")
    public ResponseEntity<String> deletePatient(@PathVariable Long id) {
        Patient patient = patientService.getPatientById(id);
        patientService.deletePatient(id);
        return ResponseEntity.ok("Patient with the name " + patient.getFirstName() + " " + patient.getLastName() + " was deleted.");
    }

    @PostMapping("appointments")
    public ResponseEntity<String> scheduleAppointment (@RequestBody AppointmentRequestDTO appointmentRequestDTO) {
        appointmentService.scheduleAppointment(appointmentRequestDTO);
        return ResponseEntity.ok("appointment scheduled");
    }

    @PutMapping("appointment/{id}")
    public ResponseEntity<String> updateAppointment(@PathVariable Long id, @RequestBody AppointmentRequestDTO appointmentRequestDTO) {
        appointmentService.updateAppointment(id, appointmentRequestDTO);
        return ResponseEntity.ok("Appointment updated");
    }

    @DeleteMapping("/appointments/{id}")
    public ResponseEntity<String> cancelAppointment(@PathVariable Long id) {
        appointmentService.cancelAppointment(id);
        return ResponseEntity.ok("Appointment canceled.");
    }

    @PutMapping("/bills/{billId}")
    public ResponseEntity<String> updatePatientBill(
            @PathVariable Long billId,
            @RequestParam BigDecimal amount) {
        billService.updateBill(billId, amount);
        return ResponseEntity.ok("Bill updated successfully.");
    }

}
