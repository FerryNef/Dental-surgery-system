package com.ads.dentalapp.dto.response;

public record RoleResponseDTO(
        String name
) {
}
