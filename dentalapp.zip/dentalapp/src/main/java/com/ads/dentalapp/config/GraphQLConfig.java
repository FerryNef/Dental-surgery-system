package com.ads.dentalapp.config;

import com.ads.dentalapp.resolver.PatientResolver;
import com.ads.dentalapp.service.PatientService;
import graphql.GraphQL;
import graphql.schema.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import static graphql.Scalars.GraphQLInt;
import static graphql.Scalars.GraphQLString;
@Component
public class GraphQLConfig {

    public static GraphQL graphQL;
    private final PatientService patientService;
    private final PatientResolver patientResolver;
    GraphQLScalarType longScalar = CustomScalars.createLongScalar();
    GraphQLScalarType localDateScalar = CustomScalars.createLocalDateScalar();

    @Autowired
    public GraphQLConfig(PatientService patientService, PatientResolver patientResolver) {
        this.patientService = patientService;
        this.patientResolver = patientResolver;
    }

    public void setupGraphQL() {
        // Define the patientType GraphQL object
        GraphQLObjectType patientType = GraphQLObjectType.newObject()
                .name("Patient")
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("id")
                        .type(longScalar)
                        .build())
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("firstName")
                        .type(GraphQLString)
                        .build())
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("lastName")
                        .type(GraphQLString)
                        .build())
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("email")
                        .type(GraphQLString)
                        .build())
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("phone")
                        .type(GraphQLString)
                        .build())
                .field(GraphQLFieldDefinition.newFieldDefinition()
                        .name("dateOfBirth")
                        .type(localDateScalar)  // Using custom LocalDate scalar
                        .build())
                .build();

        // Define the Query type and link it to the resolver
        GraphQLObjectType queryType = GraphQLObjectType.newObject()
                .name("Query")
                .field(field -> field
                        .name("getPatient")
                        .type(patientType)
                        .argument(a -> a.name("id").type(longScalar))
                        .dataFetcher(patientResolver::getPatient) // Use the resolver here
                )
                .build();

        // Create GraphQL schema with custom scalars
        GraphQLSchema graphQLSchema = GraphQLSchema.newSchema()
                .query(queryType)
                .additionalType(longScalar)
                .additionalType(localDateScalar)
                .build();

        // Initialize the GraphQL instance
        graphQL = GraphQL.newGraphQL(graphQLSchema).build();
    }

    public GraphQL getGraphQL() {
        return graphQL;
    }
}