package com.ads.dentalapp.resolver;

import com.ads.dentalapp.dto.response.AppointmentResponseDTO;
import com.ads.dentalapp.model.Appointment;
import com.ads.dentalapp.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AppointmentResolver {

    @Autowired
    private AppointmentService appointmentService;

    public List<AppointmentResponseDTO> getAppointments(Long patientId) {
        return appointmentService.getAppointmentForLoggedPatient();
    }
}
