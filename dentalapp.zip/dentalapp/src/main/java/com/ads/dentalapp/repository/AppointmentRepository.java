package com.ads.dentalapp.repository;

import com.ads.dentalapp.model.Appointment;
import com.ads.dentalapp.model.Dentist;
import com.ads.dentalapp.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByDentistId(Long dentistId);
    List<Appointment> findByDentist(Dentist dentist);

    List<Appointment> findByPatient(Patient patient);

    boolean existsByDentistIdAndDateAndTime (Long dentistId, LocalDate date, LocalTime time);
}
